/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sw;

import java.util.ArrayList;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import modelo.Cliente;
import modelo.DepositarRetirar;

/**
 *
 * @author oscar
 */
@WebService(serviceName = "TramiteSW")
public class TramiteSW {

    /**
     * This is a sample web service operation
     */
    ArrayList<Cliente> Listclient = new ArrayList();

    @WebMethod(operationName = "registro")
    public boolean registrar(@WebParam(name = "Usuario") Cliente user) {

        return Listclient.add(user);

    }

    @WebMethod(operationName = "login")
    public Cliente login(@WebParam(name = "Usuario") Cliente user) {
        Cliente cliente1 = new Cliente();

        for (Cliente cliente : Listclient) {
            if (cliente.getUser().equals(user.getUser()) && cliente.getClave().equals(user.getClave())) {
                cliente1 = cliente;
            }
        }
        return cliente1; // Inicio de sesión fallido
    }

    @WebMethod(operationName = "retiro")
    public DepositarRetirar Retiro(@WebParam(name = "numero") DepositarRetirar numero) {

        DepositarRetirar retiro = new DepositarRetirar();
        for (Cliente cliente : Listclient) {
            if (cliente.getUser().equals(numero.getUser())) {
                cliente.setSaldo(cliente.getSaldo() - numero.getCantidad());
                retiro.setCantidad(cliente.getSaldo());
                break;
            }
        }

        return retiro;
    }
     @WebMethod(operationName = "deposito")
    public DepositarRetirar Deposito(@WebParam(name = "numero") DepositarRetirar depo) {

        DepositarRetirar depositar = new DepositarRetirar();
        for (Cliente cliente : Listclient) {
            if (cliente.getUser().equals(depo.getUser())) {
                cliente.setSaldo(cliente.getSaldo() +depo.getCantidad());
                depositar.setCantidad(cliente.getSaldo());
                break;
            }
        }

        return depositar;
    }
}
