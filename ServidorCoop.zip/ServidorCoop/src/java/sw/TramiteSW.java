/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sw;

import java.util.ArrayList;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import modelo.Cliente;

/**
 *
 * @author oscar
 */
@WebService(serviceName = "TramiteSW")
public class TramiteSW {

    /**
     * This is a sample web service operation
     */
   ArrayList<Cliente> Listclient= new ArrayList();
  @WebMethod(operationName = "registro")
    public boolean registrar(@WebParam(name = "Usuario") Cliente user) {

        return Listclient.add(user);

    }
      @WebMethod(operationName = "login")
    public Cliente login(@WebParam(name = "Usuario") Cliente user) {
        Cliente cliente1= new Cliente();
        
        for (Cliente cliente : Listclient) {
            if (cliente.getUser().equals(user.getUser()) && cliente.getClave().equals(user.getClave())) {
               cliente1=cliente; 
            }
        }
        return cliente1; // Inicio de sesión fallido
    }
}
