package control;

import javax.swing.JOptionPane;
import sw.Cliente;
import sw.TramiteSW;
import sw.TramiteSW_Service;
import vista.VistaSOAP;

public class AdministrarControl {
    private VistaSOAP administrarv;
    private TramiteSW_Service servicio = new TramiteSW_Service();
    private TramiteSW tramite = servicio.getTramiteSWPort();
    Cliente cliente = new Cliente();

    public AdministrarControl(VistaSOAP administrarv) {
        this.administrarv = administrarv;
        administrarv.setVisible(true);
    }

    public void inicioControl() {
        administrarv.getBtnregistrar().addActionListener(l -> registrarUser());
        administrarv.getLblmnsjregistro().setVisible(false);
        administrarv.getBtnSalir().addActionListener(l -> regresaLogin());
        administrarv.getPnlInicioSession().setVisible(false);
        administrarv.getBtninicio().addActionListener(l -> iniciarSesion());
       
    }

    private void registrarUser() {
        String user = "";
        String clave = "";
        String repiteclave = "";
        int saldo = 0;

        user = administrarv.getTxtuserregistro().getText();
        clave = administrarv.getTxtclaveregistro().getText();
        repiteclave = administrarv.getTxtrepiteclaveregistro().getText();
        saldo = Integer.parseInt(administrarv.getSpnsaldoregistro().getValue().toString());

        if (!user.isEmpty() || !clave.isEmpty() || !repiteclave.isEmpty()) {
            System.out.println("Campos Llenos");

            if (clave.equals(repiteclave)) {
                cliente.setUser(user);
                cliente.setClave(clave);
                cliente.setSaldo(saldo);

                if (tramite.registro(cliente)) {
                    administrarv.getLblmnsjregistro().setVisible(true);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Contraseñas Incorrectas");
            }

        } else {
            JOptionPane.showMessageDialog(null, "Rellene todos los campos");
        }
    }

    public void regresaLogin() {
        administrarv.getPnlregistro().setVisible(false);
        administrarv.getPnlInicioSession().setVisible(true);
        
    }

    private void iniciarSesion() {
        String user = administrarv.getTxtusuarioinicio().getText();
        String clave = administrarv.getTxtclaveinicio().getText();

        if (!user.isEmpty() && !clave.isEmpty()) {
            cliente.setUser(user);
            cliente.setClave(clave);

            if (tramite.registro(cliente)) {
                JOptionPane.showMessageDialog(null, "Inicio de sesión exitoso");
                mostrarPanelDeposito();
            } else {
                JOptionPane.showMessageDialog(null, "Nombre de usuario o contraseña incorrectos");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Rellene todos los campos");
        }
    }
    private void mostrarPanelDeposito() {
   
    administrarv.getPnlregistro().setVisible(true);
    administrarv.getPnlInicioSession().setVisible(false);
}
    
}
